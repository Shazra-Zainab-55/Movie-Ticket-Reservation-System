from model.booking_model import BookingModel
from controller.customer_controller import CustomerController
from controller.show_controller import ShowController
from datetime import datetime

class BookingController:
    @staticmethod
    def book_ticket():
        ShowController.view_shows()
        try:
            show_id = int(input("Enter Show ID to book: "))
            seats = int(input("Enter number of seats to book: "))
        except ValueError:
            print("❌ Invalid input. Please enter numbers only.")
            return

        customer = CustomerController.find_customer()
        if not customer:
            print("Please register first.")
            CustomerController.register_customer()
            customer = CustomerController.find_customer()

        # Now call booking and capture result
        success = BookingModel.book_tickets(
            customer_id=customer['customer_id'],
            show_id=show_id,
            seats_booked=seats,
            booking_date=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        )

        if success:
            print("✅ Booking completed!")
        else:
            print("❌ Booking failed. Please try again.")
