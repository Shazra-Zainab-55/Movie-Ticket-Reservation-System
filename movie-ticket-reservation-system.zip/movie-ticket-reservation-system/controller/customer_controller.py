from model.customer_model import CustomerModel

class CustomerController:
    @staticmethod
    def register_customer():
        name = input("Enter your name: ")
        email = input("Enter your email: ")
        CustomerModel.add_customer(name, email)
        print("✅ Customer registered successfully!")

    @staticmethod
    def find_customer():
        email = input("Enter your email: ")
        customer = CustomerModel.get_customer_by_email(email)
        if customer:
            print(f"Welcome back, {customer['name']}!")
            return customer
        else:
            print("No customer found with this email.")
            return None
