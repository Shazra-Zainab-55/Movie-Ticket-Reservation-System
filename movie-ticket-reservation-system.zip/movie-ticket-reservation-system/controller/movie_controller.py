from model.movie_model import MovieModel

class MovieController:
    @staticmethod
    def create_movie():
        title = input("Enter movie title: ")
        duration = int(input("Enter duration (minutes): "))
        release_date = input("Enter release date (YYYY-MM-DD): ")
        genre = input("Enter genre: ")
        MovieModel.add_movie(title, duration, release_date, genre)
        print("✅ Movie added successfully!")

    @staticmethod
    def view_movies():
        movies = MovieModel.get_all_movies()
        print("\n🎬 Available Movies:")
        for movie in movies:
            print(f"[{movie['movie_id']}] {movie['title']} ({movie['genre']})")
