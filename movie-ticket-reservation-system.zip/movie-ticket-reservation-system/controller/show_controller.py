from model.show_model import ShowModel
from model.movie_model import MovieModel

class ShowController:

    @staticmethod
    def create_show():
        movies = MovieModel.get_all_movies()
        if not movies:
            print("No movies found. Please add a movie first.")
            return
        
        print("\nAvailable Movies:")
        for movie in movies:
            print(f"ID: {movie['movie_id']} - Title: {movie['title']}")

        movie_id = int(input("Enter movie ID for the show: "))
        start_time = input("Enter show start time (YYYY-MM-DD HH:MM:SS): ")
        available_seats = int(input("Enter available seats: "))

        ShowModel.add_show(movie_id, start_time, available_seats)

    @staticmethod
    def view_shows():
        shows = ShowModel.get_all_shows()
        for show in shows:
            print(f"ID: {show[0]}, Movie ID: {show[1]}, Start Time: {show[2]}, Available Seats: {show[3]}")
