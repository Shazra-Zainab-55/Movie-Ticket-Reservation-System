from repository.schema_initializer import initialize_schema
from view.menu import main_menu

def main():
    print("Initializing database schema...")
    initialize_schema()
    print("Database ready.\n")
    main_menu()

if __name__ == "__main__":
    main()
