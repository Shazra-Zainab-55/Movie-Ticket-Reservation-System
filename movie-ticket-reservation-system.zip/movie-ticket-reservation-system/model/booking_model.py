# model/booking_model.py

from config.config import get_db_connection

class BookingModel:
    @staticmethod
    def book_tickets(customer_id, show_id, seats_booked, booking_date):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        try:
            # Start transaction
            conn.start_transaction()

            # Check available seats
            cursor.execute('SELECT available_seats FROM Shows WHERE show_id = %s', (show_id,))
            show = cursor.fetchone()

            if show and show['available_seats'] >= seats_booked:
                # Update available seats
                cursor.execute('''
                    UPDATE Shows
                    SET available_seats = available_seats - %s
                    WHERE show_id = %s
                ''', (seats_booked, show_id))

                # Insert booking record
                cursor.execute('''
                    INSERT INTO Bookings (customer_id, show_id, seats_booked, booking_date)
                    VALUES (%s, %s, %s, %s)
                ''', (customer_id, show_id, seats_booked, booking_date))

                conn.commit()
                print("\u2705 Booking completed!")
            else:
                print("\u274C Not enough seats available. Booking cancelled.")
                conn.rollback()

        except Exception as e:
            conn.rollback()
            print(f"\u274C Booking failed: {str(e)}")
        finally:
            cursor.close()
            conn.close()