from config.config import get_db_connection

class CustomerModel:
    @staticmethod
    def add_customer(name, email):
        conn = get_db_connection()
        cursor = conn.cursor()
        query = '''
            INSERT INTO Customers (name, email)
            VALUES (%s, %s);
        '''
        cursor.execute(query, (name, email))
        conn.commit()
        conn.close()

    @staticmethod
    def get_customer_by_email(email):
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        query = '''
            SELECT * FROM Customers WHERE email = %s
        '''
        cursor.execute(query, (email,))
        customer = cursor.fetchone()
        conn.close()
        return customer
