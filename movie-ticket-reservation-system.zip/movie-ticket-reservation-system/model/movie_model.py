from config.config import get_db_connection

class MovieModel:

    @staticmethod
    def add_movie(title, duration, release_date, genre):
        conn = get_db_connection()
        cursor = conn.cursor()
        query = '''
            INSERT INTO Movies (title, duration, release_date, genre)
            VALUES (%s, %s, %s, %s);
        '''
        cursor.execute(query, (title, duration, release_date, genre))
        conn.commit()
        conn.close()

    @staticmethod
    def get_all_movies():
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        query = "SELECT * FROM Movies"
        cursor.execute(query)
        movies = cursor.fetchall()
        conn.close()
        return movies

    @staticmethod
    def update_movie(movie_id, title):
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "UPDATE Movies SET title = %s WHERE movie_id = %s"
        cursor.execute(query, (title, movie_id))
        conn.commit()
        conn.close()

    @staticmethod
    def delete_movie(movie_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "DELETE FROM Movies WHERE movie_id = %s"
        cursor.execute(query, (movie_id,))
        conn.commit()
        conn.close()
