from config.config import get_db_connection

class ShowModel:

    @staticmethod
    def add_show(movie_id, start_time, available_seats):
        conn = get_db_connection()
        cursor = conn.cursor()
        query = '''
            INSERT INTO Shows (movie_id, start_time, available_seats)
            VALUES (%s, %s, %s);
        '''
        cursor.execute(query, (movie_id, start_time, available_seats))
        conn.commit()
        conn.close()

    @staticmethod
    def get_all_shows():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Shows;')
        shows = cursor.fetchall()
        conn.close()
        return shows
