-- DROP all tables if exist
DROP TABLE IF EXISTS Bookings;
DROP TABLE IF EXISTS Shows;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Movies;

-- 1. DDL - Create tables
CREATE TABLE Movies (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    duration INT NOT NULL,
    release_date DATE,
    genre VARCHAR(100)
);

CREATE TABLE Shows (
    show_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT,
    start_time DATETIME,
    available_seats INT,
    FOREIGN KEY (movie_id) REFERENCES Movies(movie_id)
);

CREATE TABLE Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE Bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    show_id INT,
    seats_booked INT,
    booking_date DATETIME,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (show_id) REFERENCES Shows(show_id)
);

-- 2. DML Examples
-- (You will also do INSERT, UPDATE, DELETE in your project code.)

-- 3. Stored Procedure
DELIMITER $$
CREATE PROCEDURE AddBooking(
    IN p_customer_id INT,
    IN p_show_id INT,
    IN p_seats_booked INT
)
BEGIN
    INSERT INTO Bookings(customer_id, show_id, seats_booked, booking_date)
    VALUES (p_customer_id, p_show_id, p_seats_booked, NOW());
END $$
DELIMITER ;

-- 4. Scalar Function (returns a single value)
DELIMITER $$
CREATE FUNCTION get_total_seats_booked(p_customer_id INT)
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE total_seats INT;
    SELECT COALESCE(SUM(seats_booked), 0) INTO total_seats
    FROM Bookings
    WHERE customer_id = p_customer_id;
    RETURN total_seats;
END $$
DELIMITER ;

-- 5. Inline Table-Valued Function
-- MySQL does not support true inline table-valued functions, but we use a View
CREATE OR REPLACE VIEW get_customer_bookings AS
SELECT 
    c.name AS customer_name,
    m.title AS movie_title,
    s.start_time,
    b.seats_booked
FROM Bookings b
INNER JOIN Customers c ON b.customer_id = c.customer_id
INNER JOIN Shows s ON b.show_id = s.show_id
INNER JOIN Movies m ON s.movie_id = m.movie_id;

-- 6. Triggers
-- (a) BEFORE INSERT - Check seat availability
DELIMITER $$
CREATE TRIGGER before_booking
BEFORE INSERT ON Bookings
FOR EACH ROW
BEGIN
    DECLARE available INT;
    SELECT available_seats INTO available
    FROM Shows
    WHERE show_id = NEW.show_id;
    
    IF available < NEW.seats_booked THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not enough seats available!';
    END IF;
END $$
DELIMITER ;

-- (b) AFTER INSERT - Update available seats
DELIMITER $$
CREATE TRIGGER after_booking
AFTER INSERT ON Bookings
FOR EACH ROW
BEGIN
    UPDATE Shows
    SET available_seats = available_seats - NEW.seats_booked
    WHERE show_id = NEW.show_id;
END $$
DELIMITER ;

-- 7. Join Examples

-- INNER JOIN Example
SELECT c.name, m.title, s.start_time, b.seats_booked
FROM Bookings b
INNER JOIN Customers c ON b.customer_id = c.customer_id
INNER JOIN Shows s ON b.show_id = s.show_id
INNER JOIN Movies m ON s.movie_id = m.movie_id;

-- LEFT JOIN Example
SELECT c.name, b.booking_id
FROM Customers c
LEFT JOIN Bookings b ON c.customer_id = b.customer_id;

-- RIGHT JOIN Example (works in MySQL)
SELECT b.booking_id, c.name
FROM Bookings b
RIGHT JOIN Customers c ON c.customer_id = b.customer_id;

-- FULL JOIN (simulated using UNION of LEFT JOIN and RIGHT JOIN)
SELECT c.name, b.booking_id
FROM Customers c
LEFT JOIN Bookings b ON c.customer_id = b.customer_id
UNION
SELECT c.name, b.booking_id
FROM Customers c
RIGHT JOIN Bookings b ON c.customer_id = b.customer_id;

-- 8. Transaction Example

START TRANSACTION;

-- Suppose insert a new booking
INSERT INTO Bookings (customer_id, show_id, seats_booked, booking_date)
VALUES (1, 2, 3, NOW());

-- If everything is fine
COMMIT;

-- If any error
-- ROLLBACK;


