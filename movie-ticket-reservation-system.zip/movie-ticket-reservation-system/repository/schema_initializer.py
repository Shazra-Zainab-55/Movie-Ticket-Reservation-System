# repository/schema_initializer.py

from config.config import get_db_connection

def initialize_schema():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Movies (
            movie_id INT PRIMARY KEY AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            duration INT NOT NULL,
            release_date DATE,
            genre VARCHAR(100)
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Shows (
            show_id INT PRIMARY KEY AUTO_INCREMENT,
            movie_id INT,
            start_time DATETIME,
            available_seats INT,
            FOREIGN KEY (movie_id) REFERENCES Movies(movie_id)
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Customers (
            customer_id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL
        );
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Bookings (
            booking_id INT PRIMARY KEY AUTO_INCREMENT,
            customer_id INT,
            show_id INT,
            seats_booked INT,
            booking_date DATETIME,
            FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
            FOREIGN KEY (show_id) REFERENCES Shows(show_id)
        );
    ''')

    conn.commit()
    conn.close()
