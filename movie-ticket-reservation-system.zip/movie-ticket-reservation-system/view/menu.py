from controller.movie_controller import MovieController
from controller.show_controller import ShowController
from controller.customer_controller import CustomerController
from controller.booking_controller import BookingController

def main_menu():
    while True:
        print("\n🎟️ Movie Ticket Reservation System 🎟️")
        print("1. Add Movie")
        print("2. Add Show")
        print("3. Register Customer")
        print("4. View Movies")
        print("5. View Shows")
        print("6. Book Ticket")
        print("7. Exit")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            MovieController.create_movie()
        elif choice == '2':
            ShowController.create_show()
        elif choice == '3':
            CustomerController.register_customer()
        elif choice == '4':
            MovieController.view_movies()
        elif choice == '5':
            ShowController.view_shows()
        elif choice == '6':
            BookingController.book_ticket()
        elif choice == '7':
            print("Goodbye!")
            break
        else:
            print("Invalid choice! Please try again.")
